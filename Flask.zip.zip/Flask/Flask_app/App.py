from flask import Flask, render_template, request
import re
import math
import requests
import hashlib
import random
import string

app = Flask(__name__)

def load_common_passwords():
    try:
        with open("common_passwords.txt", "r") as file:
            return set(line.strip() for line in file)
    except FileNotFoundError:
        return set()

def calculate_entropy(password):
    charset = 0
    if re.search(r"[a-z]", password): charset += 26
    if re.search(r"[A-Z]", password): charset += 26
    if re.search(r"[0-9]", password): charset += 10
    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password): charset += 32
    return len(password) * math.log2(charset) if charset else 0

def strength_score(password):
    score = 0
    if len(password) >= 8: score += 20
    if re.search(r"[A-Z]", password): score += 20
    if re.search(r"[0-9]", password): score += 20
    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password): score += 20
    if len(password) >= 12: score += 20
    return min(score, 100)

def check_pwned(password):
    sha1 = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    prefix, suffix = sha1[:5], sha1[5:]
    try:
        res = requests.get(f'https://api.pwnedpasswords.com/range/{prefix}')
        hashes = (line.split(':') for line in res.text.splitlines())
        for hash_suffix, count in hashes:
            if hash_suffix == suffix:
                return int(count)
    except:
        pass
    return 0

def generate_suggestion():
    return ''.join(random.choices(string.ascii_letters + string.digits + '!@#$', k=12))

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    suggestion = None
    breach_count = 0
    score = 0
    password = ""

    if request.method == "POST":
        password = request.form["password"]
        common_passwords = load_common_passwords()
        score = strength_score(password)
        breach_count = check_pwned(password)

        if password in common_passwords:
            result = "Very Weak – Commonly used password"
        elif len(password) < 6:
            result = "Very Weak – Too short"
        elif score < 40:
            result = "Weak – Improve length and variety"
        elif score < 70:
            result = "Moderate – Decent, but improvable"
        elif score < 90:
            result = "Strong – Good password"
        else:
            result = "Very Strong – Excellent password"

        if score < 60:
            suggestion = generate_suggestion()

        return render_template("index.html", password=password, result=result,
                               score=score, suggestion=suggestion, breach_count=breach_count)

    return render_template("index.html")
